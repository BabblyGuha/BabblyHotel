package com.cg.universityadmission.exception;

public class UASException extends Exception {

	public UASException(String message) {
		super(message);
	}
}
