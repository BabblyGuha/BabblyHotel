package com.capgemini.takecareclinic.ui;

import java.io.IOException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.takecareclinic.bean.PatientBean;
import com.capgemini.takecareclinic.exception.PatientException;
import com.capgemini.takecareclinic.service.IPatientService;
import com.capgemini.takecareclinic.service.PatientService;

public class Client {

	IPatientService service = null;

	public static void main(String[] args) throws IOException, PatientException {

		Logger logg = Logger.getRootLogger();
		
		Scanner scanner  = new Scanner(System.in);
		do {
			
			//Displaying Menu for user
			System.out.println("1. Add Patient Information");
			System.out.println("2. Exit");

			System.out.println("Enter your choice: ");
			int choice = scanner.nextInt();

			switch (choice) {
			case 1:
				//For storing details of new patient
				System.out.print("Enter the name of the Patient: ");
				String patient_name = scanner.next();

				System.out.print("Enter Patient Age: ");
				int age = scanner.nextInt();

				System.out.print("Enter Patient phone number: ");
				String phone = scanner.next();

				System.out.print("Enter Description: ");
				String description = scanner.next();

				System.out.println();
				
				//Creating an object for PatientBean and assigning values to the object variables using setters
				PatientBean patient = new PatientBean();
				patient.setPatient_name(patient_name);
				patient.setAge(age);
				patient.setPhone(phone);
				patient.setDescription(description);

				int patient_id;
				
				//Storing the patient id generated for the new patient
				patient_id = new Client().addPatientDetails(patient);
				if (patient_id != 0) {
					logg.info("Patient Information stored successfully for "+ patient_id);//Storing in log file patient.log
					System.out.println("Patient Information stored successfully for "+ patient_id);
					System.out.println();
				} else {
					logg.error("New Patient Id not generated successfully !!!");//Storing in log file patient.log
					System.err.println("New Patient Id not generated successfully !!!");
				}
				break;

			case 2:
				//For exiting the application
				System.out.println("You have successfully exited. Thank you !!!");
				System.exit(0);
				break;
			}
		} while (true);
	}

	
	/*
	 * This function will call the service implementation method PatientService passing an object of patient
	 * and will return the new patient id
	 */
	public int addPatientDetails(PatientBean patient)throws PatientException {
		service = new PatientService();
		return service.addPatientDetails(patient);

	}

}
