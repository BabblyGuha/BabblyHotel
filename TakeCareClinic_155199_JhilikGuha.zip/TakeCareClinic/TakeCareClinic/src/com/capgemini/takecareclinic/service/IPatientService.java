package com.capgemini.takecareclinic.service;

import com.capgemini.takecareclinic.bean.PatientBean;
import com.capgemini.takecareclinic.exception.PatientException;

public interface IPatientService {

	
	public abstract int addPatientDetails(PatientBean patient) throws PatientException;
}
