package com.capgemini.takecareclinic.service;

import com.capgemini.takecareclinic.bean.PatientBean;
import com.capgemini.takecareclinic.dao.IPatientDAO;
import com.capgemini.takecareclinic.dao.PatientDAO;
import com.capgemini.takecareclinic.exception.PatientException;

public class PatientService implements IPatientService{

	IPatientDAO patient_dao = null;
	
	/*
	 * This function will call the DAO implementation method PatientDAO passing an object of patient and will return the new patient id
	 */
	
	//------------------------ 1. Take Care Clinic Software Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	addPatientDetails(PatientBean patient)
		 - Input Parameters	:	PatientBean object
		 - Return Type		:	int id
		 - Throws			:  	PatientException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	17/08/2018
		 - Description		:	adding patient to database and calls DAO addPatientDetails(PatientBean patient)
		 ********************************************************************************************************/
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {

		patient_dao = new PatientDAO();
		return patient_dao.addPatientDetails(patient);
	}

}
