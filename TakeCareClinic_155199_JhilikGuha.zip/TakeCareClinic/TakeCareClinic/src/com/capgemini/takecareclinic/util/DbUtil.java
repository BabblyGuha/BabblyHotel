package com.capgemini.takecareclinic.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.takecareclinic.exception.PatientException;

public class DbUtil {

	static Connection conn = null;

	/*****************************************************************
	 *  - Method Name: establishConnection() 
	 *  - Input Parameters : 
	 *  - Return Type : DB Connection instance
	 *  - Throws : PatientException 
	 *  - Author : CAPGEMINI 
	 *  - Creation Date : 17/08/2018
	 *  - Description :  Returns connection object
	 * @throws PatientException 
	 *******************************************************************/
	
	public static Connection establishConnection() throws PatientException {

		Logger logg = Logger.getRootLogger();
		
		try {
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg209","training209");
		} catch (SQLException e) {

			logg.error("SQL Connection problem !!!");
			System.err.println("SQL Connection problem !!!");
			throw new PatientException("SQL Connection problem !!!");
		}

		return conn;
	}
}
