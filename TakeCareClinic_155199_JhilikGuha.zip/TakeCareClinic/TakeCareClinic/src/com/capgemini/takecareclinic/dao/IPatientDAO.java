package com.capgemini.takecareclinic.dao;

import com.capgemini.takecareclinic.bean.PatientBean;
import com.capgemini.takecareclinic.exception.PatientException;

public interface IPatientDAO {

	public abstract int addPatientDetails(PatientBean patient) throws PatientException;
	
}
