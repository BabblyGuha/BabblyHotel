package com.capgemini.takecareclinic.dao;

public class IQueryMapper {

	public static final String INSERT_QUERY="INSERT INTO Patient VALUES (Patient_Id_Seq.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String ID="SELECT Patient_Id_Seq.CURRVAL FROM Dual";
	
}
