package com.capgemini.takecareclinic.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.takecareclinic.bean.PatientBean;
import com.capgemini.takecareclinic.exception.PatientException;
import com.capgemini.takecareclinic.util.DbUtil;

public class PatientDAO implements IPatientDAO {

	private Connection conn = null;

	//------------------------ 1. Take Care Clinic Software Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addPatientDetails(PatientBean patient)
			 - Input Parameters	:	PatientBean patient
			 - Return Type		:	int
			 - Throws			:  	PatientException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	17/08/2018
			 - Description		:	Adding Patient
			 ********************************************************************************************************/
	@Override
	public int addPatientDetails(PatientBean patient)
			throws PatientException {
		Logger logg = Logger.getRootLogger();
		
		int patient_id = 0;
		try {
			conn = DbUtil.establishConnection();
			PreparedStatement preparedstatement = conn
					.prepareStatement(IQueryMapper.INSERT_QUERY);
			preparedstatement.setString(1, patient.getPatient_name());
			preparedstatement.setInt(2, patient.getAge());
			preparedstatement.setString(3, patient.getPhone());
			preparedstatement.setString(4, patient.getDescription());

			int storedStatus = preparedstatement.executeUpdate();
			if (storedStatus == 1) {
				PreparedStatement stmt = conn.prepareStatement(IQueryMapper.ID);
				ResultSet rs = stmt.executeQuery();
				rs.next();
				patient_id = rs.getInt(1);

			} else {

				System.err.println("Error in adding new Patient information");
			}
		} catch (SQLException e) {

			logg.error("Error in adding Patient information: " + e.getMessage());
			throw new PatientException("Error in adding Patient information: "
					+ e.getMessage());

		}
		return patient_id;
	}

}
