package com.capgemini.takecareclinic.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.takecareclinic.bean.PatientBean;
import com.capgemini.takecareclinic.dao.PatientDAO;
import com.capgemini.takecareclinic.exception.PatientException;

public class PatientDAOTest {

	@Test
	public void test() throws PatientException {		
		PatientBean patient = new PatientBean("Jhilik", 25, "9852630147", "Fever");
		PatientDAO patient_dao = new PatientDAO();
		
		assertEquals(1025,patient_dao.addPatientDetails(patient));
	}
	@Test
	public void test1() throws PatientException {		
		PatientBean patient = new PatientBean("Jhilik", 15, "9852630147", "Headache");
		PatientDAO patient_dao = new PatientDAO();
		
		assertEquals(1001,patient_dao.addPatientDetails(patient));
	}
}
